<?php

return [
    'host' => 'mysql',
    'dbname' => 'resto',
    'user' => 'app',
    'pass' => 'app'
];
