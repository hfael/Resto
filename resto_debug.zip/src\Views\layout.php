<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Restaurant</title>
</head>
<body>

<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$connected = isset($_SESSION['user_id']);
?>

<header>
    <a href="/home/index">Accueil</a>

    <?php if ($connected): ?>
        <php class="info"></php>
        <a href="/dish/index">Plats</a>
        <a href="/reservation/index">Réservations</a>
        <a href="/logout/index">Déconnexion</a>
    <?php else: ?>
        <a href="/login/index">Connexion</a>
        <a href="/register/index">Inscription</a>
    <?php endif; ?>
</header>

<main>
    {{content}}
</main>

<footer>
    © Restaurant – Projet Étudiant
</footer>

</body>
</html>
