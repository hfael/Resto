<?php

class View {
    public static function render($content) {
        $layout = file_get_contents(__DIR__.'/Views/layout.php');
        echo str_replace('{{content}}', $content, $layout);
    }
}
